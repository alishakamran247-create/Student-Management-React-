import StudentForm from "./components/StudentForm.jsx";
import StudentList from "./components/StudentList.jsx";
import ApiData from "./components/ApiData.jsx";
import { StudentProvider } from "./context/StudentContext.jsx";

function App() {
  return (
    <StudentProvider>
      <h1>Student Information App</h1>
      <StudentForm />
      <StudentList />
      <ApiData />
    </StudentProvider>
  );
}

export default App;
