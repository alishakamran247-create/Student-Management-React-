import { useState, useContext } from "react";
import { StudentContext } from "../context/StudentContext";

const StudentForm = () => {
  const { addStudent } = useContext(StudentContext);

  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [course, setCourse] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    addStudent({ name, age, course });

    setName("");
    setAge("");
    setCourse("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add Student</h2>

      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />

      <input
        type="number"
        placeholder="Age"
        value={age}
        onChange={(e) => setAge(e.target.value)}
        required
      />

      <input
        type="text"
        placeholder="Course"
        value={course}
        onChange={(e) => setCourse(e.target.value)}
        required
      />

      <button type="submit">Add Student</button>
    </form>
  );
};

export default StudentForm;
