import { useContext } from "react";
import { StudentContext } from "../context/StudentContext";

const StudentList = () => {
  const { students } = useContext(StudentContext);

  return (
    <div>
      <h2>Student List</h2>

      {students.length === 0 && <p>No students added yet.</p>}

      <ul>
        {students.map((student, index) => (
          <li key={index}>
            {student.name} | Age: {student.age} | Course: {student.course}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StudentList;
